function [TrainingAccuracy]=classification_tr(InputWeight, ActivationFunction, batch_num, number_of_AEs, subnetwork, sub, relu)
layer=1;

for i=1:number_of_AEs+1
    InputWeight1=InputWeight{i};
    if i < number_of_AEs+1
        layer=initial_layer(InputWeight1,layer,relu,ActivationFunction,batch_num);%1st layer
    end
    if i == number_of_AEs && subnetwork == sub
        Obtain_feature(batch_num, layer);
    end
    if i == number_of_AEs+1
        forward_lastlayer(batch_num, ActivationFunction, InputWeight1, layer, number_of_AEs);%?????????????y.????
    end
end

TrNo=0;
MissClassificationRate_Training=0;
for batch=1:batch_num %This iteration just for obtaining the exact (right) hidden feature data.
    filename1=['layer_1\H_f\' 'H_train-feature' num2str(number_of_AEs+1) '_batchNo' num2str(batch) '.mat'];
    load(filename1);
    filename3=['layer_1\X_i\T-TRAIN' num2str(batch) '.mat'];
    load(filename3);
    for j = 1 : size(T_train, 2)
        [x, label_index_expected]=max(T_train(:,j));
        [x, label_index_actual]=max(Y_out(:,j));
        if label_index_actual~=label_index_expected
            MissClassificationRate_Training=MissClassificationRate_Training+1;
        end
    end
    TrNo=TrNo+size(T_train, 2);
end
TrainingAccuracy = 1-MissClassificationRate_Training/TrNo;
TrainingAccuracy=roundn(TrainingAccuracy,-4);
end