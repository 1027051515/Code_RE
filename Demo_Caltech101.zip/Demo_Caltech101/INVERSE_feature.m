function [P_out_map]=INVERSE_feature(T_train, ActivationFunction, belta, C, learning_rate2)
%C=40;
%C=C;

P_in=T_train;
OutputNO=size(P_in,1);
HiddenNO=size(P_in,2);
if C == 0%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    P_out_map=pinv(belta)*P_in;
elseif  HiddenNO <= OutputNO
    P_out_map=(belta'*belta+eye(size(belta,2))/C)\belta'*P_in;
elseif  HiddenNO > OutputNO
    %P_out_map=(belta'*belta+eye(size(belta,2))/C)\belta'*P_in;
    P_out_map=belta'/(belta*belta'+eye(size(belta,1))/C)*P_in;
end
P_out_map= learning_rate2*P_out_map;


end